<?php
// This file was auto-generated from sdk-root/src/data/sqs/2012-11-05/paginators-1.json
return [ 'pagination' => [ 'ListQueues' => [ 'result_key' => 'QueueUrls', ], ],];
