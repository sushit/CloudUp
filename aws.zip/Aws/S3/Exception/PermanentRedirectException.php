<?php
namespace Aws\S3\Exception;

class PermanentRedirectException extends S3Exception {}
